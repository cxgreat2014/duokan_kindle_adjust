#!/bin/sh
/mnt/us/DK_System/install/DuoKanInstall.sh